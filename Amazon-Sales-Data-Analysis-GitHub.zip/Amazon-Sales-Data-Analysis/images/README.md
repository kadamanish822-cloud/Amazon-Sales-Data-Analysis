# Images

This folder can be used for selected charts/screenshots from the analysis if you want to showcase them in the GitHub README.
