# Dataset

The original dataset is not included in this repository.

If the dataset can legally be redistributed, place the CSV file in this folder and update the notebook's file path accordingly.

For GitHub sharing, avoid using a personal Windows path such as:
`C:\Users\...`

Prefer a relative path such as:
`data/amazon.csv`
